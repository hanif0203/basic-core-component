import { View } from "react-native";

// Functional Component with props
const Separator = (props) => {
  return <View style={{ height: props.height }}></View>;
};

export default Separator;
